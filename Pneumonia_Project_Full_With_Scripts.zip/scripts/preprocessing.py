
# preprocessing.py
import pandas as pd
from sklearn.impute import SimpleImputer

def load_data(file_path):
    """Load CSV dataset into a Pandas DataFrame."""
    df = pd.read_csv(file_path)
    return df

def preprocess_data(df):
    """Handle missing values and faulty ages."""
    imputer = SimpleImputer(strategy='mean')
    df[['Humidity_Percent', 'Rainfall_mm']] = imputer.fit_transform(df[['Humidity_Percent', 'Rainfall_mm']])
    df = df[df['Age_Months'] <= 60]
    return df

if __name__ == "__main__":
    df = load_data("../data/Bangladesh_Pneumonia_U5_Winter_10yrs.csv")
    df_clean = preprocess_data(df)
    print("Data loaded and preprocessed. Shape:", df_clean.shape)
